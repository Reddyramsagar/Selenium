package com.lab7.exercises;

public class TrimStatement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
